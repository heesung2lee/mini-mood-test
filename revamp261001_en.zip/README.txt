Resonate Tour docs 2026-10-06 rev4 (3rd-party vs entrust + transfer fix)
01 quote / 02 contract / 03 privacy / 04 insurance / 05 voucher / 06 settlement / 07 receipt

Resonate Tour docs 2026-10-01 (all Korean, 법률자문 아님)
01_quote.docx = 견적서
02_contract.docx = 국외여행계약서(희망여행)
03_privacy_consent.docx = 개인정보동의서
04_insurance_guide.docx = 여행자보험안내(비자표+외국인가족+카드보험)
05_confirmation_voucher.docx = 확정서·바우처
06_settlement.docx = 정산서
07_receipt_ack.docx = 수신확인서

Resonate Tour docs 2026-10-06 rev5 (gemini merge: FX/TASF/TTL/RainCheck/secrecy)
01 quote / 02 contract / 03 privacy / 04 insurance / 05 voucher / 06 settlement / 07 receipt
